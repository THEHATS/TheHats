<div class="socialbar">
<p>
<strong><span>Submit Article :- </span></strong>
<a href="http://blinklist.com/index.php?Action=Blink/addblink.php&amp;Description=<?php the_title() ?>&amp;Url=<?php the_permalink() ?>" title="BlinkList Submit" target="_blank"> BlinkList</a> +
<a href="http://blogmarks.net/my/new.php?mini=1&amp;title=<?php the_title() ?>&amp;url=<?php the_permalink() ?>" title="Blogmarks" target="_blank">Blogmarks</a> +
<a href="http://www.digg.com/submit?phase=2&amp;url=<?php the_permalink() ?>&amp;title=<?php the_title() ?>" title="Submit Post to Digg" target="_blank">Digg</a> +
<a href="http://del.icio.us/post?url=<?php the_permalink() ?>&amp;title=<?php the_title() ?>" title="Submit to Del.icio.us" target="_blank">Del.icio.us</a> +
<a href="http://ekstreme.com/socializer/?url=<?php the_permalink() ?>&amp;title=<?php the_title() ?>" title="Ekstreme Socializer" target="_blank">Ekstreme Socializer</a> +
<a href="http://www.feedmarker.com/admin.php?do=bookmarklet_mark&amp;url=<?php the_permalink() ?>&amp;title=<?php the_title() ?>;" title="Submit to Feedmarker" target="_blank">Feedmarker</a> +
<a href="http://furl.net/storeIt.jsp?t=<?php the_title() ?>&amp;u=<?php the_permalink() ?>" title="Submit to Furl" target="_blank">Furl</a> +
<a href="http://www.google.com/bookmarks/mark?op=add&amp;bkmk=<?php the_permalink() ?>&amp;title=<?php the_title() ?>" title="Submit to Google Bookmarks" target="_blank">Google Bookmarks</a> +
<a href="http://ma.gnolia.com/bookmarklet/add?%20url=<?php the_permalink() ?>&amp;title=<?php the_title() ?>" title="Submit to ma.gnolia" target="_blank">ma.gnolia</a> +
<a href="http://www.netvouz.com/action/submitBookmark?url=<?php the_permalink() ?>&amp;title=<?php the_title() ?>" title="submit to Netvous" target="_blank">Netvouz</a> +
<a href="http://www.rawsugar.com/pages/tagger.faces?turl=<?php the_permalink() ?>;&amp;tttl=<?php the_title() ?>" title="Save to RawSugar" target="_blank">RawSugar</a> +
<a href="http://reddit.com/submit?url=<?php the_permalink() ?>&amp;title=<?php the_title() ?>" title="Submit Reddit" target="_blank">Reddit</a> +
<a href="http://scuttle.org/bookmarks.php/pass?action=add&amp;address=<?php the_permalink() ?>&amp;title=<?php the_title() ?>" title="Submit to Scuttle" target="_blank">Scuttle</a> +
<a href="http://www.shadows.com/features/tcr.htm?url=<?php the_permalink() ?>&amp;title=<?php the_title() ?>" title="Submit to Shadows" target="_blank">Shadows</a> +
<a href="http://www.simpy.com/simpy/LinkAdd.do?href=<?php the_permalink() ?>&amp;title=<?php the_title() ?>" title="Submit to Simpy" target="_blank">Simpy</a> +
<a href="http://www.spurl.net/spurl.php?title=<?php the_title() ?>&amp;url=<?php the_permalink() ?>" title="submit to Spurl" target="_blank">Spurl</a> +
<a href="http://technorati.com/faves?add=<?php the_permalink() ?>" title="Submit to Technorati" target="_blank">Technorati</a> +
<a href="http://unalog.com/my/stack/link?url=<?php the_permalink() ?>&amp;title=<?php the_title() ?>" title="Submit to Unalog" target="_blank">Unalog</a> +
<a href="http://www.wink.com/_/tag?url=<?php the_permalink() ?>&amp;doctitle=<?php the_title() ?>" title="Submit to Wink" target="_blank">Wink</a>
</p>
</div>