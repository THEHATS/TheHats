<div id="sidebar">

<div class="boxes">
<h2>Author</h2>
<p>A little something about you, the author. Nothing lengthy, just an overview. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
</div>

<div class="boxes">
<h2>Subscribe</h2>
<a href="http://feeds.feedburner.com/blogohblog" rel="alternate" type="application/rss+xml" class="rss">Subscribe via RSS</a> | <a href="<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a> 
<br /><br />
<form action="http://www.feedburner.com/fb/a/emailverify" method="post" target="popupwindow" onsubmit="window.open('http://www.feedburner.com', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true">Or, subscribe via email:&nbsp;<input type="text" class="subscribetext"  name="email"/><input type="hidden" value="http://feeds.feedburner.com/~e?ffid=950698" name="url"/><input type="hidden" value="Me, Blog Design and Make Money" name="title"/><input type="hidden" name="loc" value="en_US"/>&nbsp;<input type="submit" value="Subscribe" class="subscribebutton" /></form>
</div>

<div class="boxes">
<h2>Advertising</h2>
<a href="#" class="ads"><img src="<?php bloginfo('template_directory'); ?>/ads/ad.gif" border="0" alt="Ad" /></a>
<a href="#" class="ads"><img src="<?php bloginfo('template_directory'); ?>/ads/ad.gif" border="0" alt="Ad" /></a>
<a href="#" class="ads"><img src="<?php bloginfo('template_directory'); ?>/ads/ad.gif" border="0" alt="Ad" /></a>
</div>

<br />

<div id="lsidebar">
<?php include (TEMPLATEPATH . '/lsidebar.php'); ?>
</div>

<div id="rsidebar">
<?php include (TEMPLATEPATH . '/rsidebar.php'); ?>
</div>
<div class="clear"></div>
</div>

