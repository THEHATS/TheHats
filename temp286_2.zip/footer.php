<div class="clear"></div>
</div>
<div id="footer">
<p style="float:left;"><?php bloginfo('name'); ?> is proudly powered by <a href="http://wordpress.org/">WordPress</a> | Firebug Theme by <a href="http://www.blogohblog.com" title="Free WordPress Themes">Blog Oh! Blog</a><!-- <?php echo get_num_queries(); ?> queries. <?php timer_stop(1); ?> seconds. -->
	</p>
    <p style="float:right;">
    <a href="http://jigsaw.w3.org/css-validator/"><img src="<?php bloginfo('template_directory'); ?>/images/css.gif" alt="Valid CSS!" /></a> <a href="http://validator.w3.org/check?uri=referer"><img src="<?php bloginfo('template_directory'); ?>/images/xhtml.gif" alt="Valid XHTML 1.0 Transitional" /></a>
    </p>
    <br clear="all" />
</div>
</div>
<?php wp_footer(); ?>
<!--%@##--><div style="margin: 1em 0 3em 0; text-align: center;">Find more free <a href="http://www.freewebtemplates.com/wordpress-themes/">WordPress themes</a> at <a href="http://www.freewebtemplates.com/">Free Website Templates</a>.</div><!--##@%-->
</body>
</html>
